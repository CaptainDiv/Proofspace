sudo nitro-cli terminate-enclave --all
sudo killall socat
#